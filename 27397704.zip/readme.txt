To run the game, simply run the "CTF 476.exe" file.

To exit, you need to alt+f4 as there is no other way to exit, unless you choose window-mode.

Controls:
Press 1 for Kinematic
Press 2 for Steering

The game logic can be found in game.cs and the AI logic will be in npc.cs